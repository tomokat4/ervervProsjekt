package com.example.dev_erverv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevErvervApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevErvervApplication.class, args);
	}

}
