package com.example.dev_erverv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevErvervApplicationTests {

	@Test
	void contextLoads() {
	}

}
